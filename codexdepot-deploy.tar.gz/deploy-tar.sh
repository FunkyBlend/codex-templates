#!/usr/bin/env bash
set -euo pipefail

JUMP_HOST="flashadmin@159.65.246.230"
TARGET_HOST="flashadmin@167.71.205.41"
REMOTE_DIR="/opt/codex-marketplace"
ARCHIVE_NAME="codexdepot-deploy.tar.gz"

echo "==> [1/5] Creating deployment archive..."
tar -czf "$ARCHIVE_NAME" \
  --exclude='node_modules' \
  --exclude='.next' \
  --exclude='.git' \
  --exclude='.env' \
  --exclude='*.log' \
  .

echo "==> [2/5] Transferring archive to target via jump host..."
scp -J "$JUMP_HOST" "$ARCHIVE_NAME" "$TARGET_HOST:/tmp/$ARCHIVE_NAME"

echo "==> [3/5] Extracting and building on remote server..."
ssh -J "$JUMP_HOST" "$TARGET_HOST" bash <<'REMOTE'
set -euo pipefail
REMOTE_DIR="/opt/codex-marketplace"

sudo mkdir -p "$REMOTE_DIR"
sudo chown -R flashadmin:flashadmin "$REMOTE_DIR"

echo "Extracting archive..."
tar -xzf "/tmp/codexdepot-deploy.tar.gz" -C "$REMOTE_DIR"

cd "$REMOTE_DIR"

# Install Node 20 if missing
if ! command -v node &>/dev/null || [[ "$(node -v)" != v20* ]]; then
  echo "Installing Node.js 20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi

# Install PM2 if missing
if ! command -v pm2 &>/dev/null; then
  echo "Installing PM2..."
  sudo npm install -g pm2
fi

echo "Installing dependencies..."
npm ci

echo "Building Next.js application..."
npm run build
REMOTE

echo "==> [4/5] Starting / restarting app with PM2..."
ssh -J "$JUMP_HOST" "$TARGET_HOST" bash <<'REMOTE'
set -euo pipefail
cd /opt/codex-marketplace

if pm2 list | grep -q "codex-marketplace"; then
  pm2 restart codex-marketplace
else
  pm2 start ecosystem.config.js || pm2 start npm --name "codex-marketplace" -- start
  pm2 save
fi
REMOTE

echo "==> [5/5] Cleaning up local archive..."
rm "$ARCHIVE_NAME"

echo ""
echo "✅ Deployment complete!"
echo "   Site should be live at: http://167.71.205.41"
