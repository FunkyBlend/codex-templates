# Next.js Codex Starter

## Usage
1. Copy the files under `files/` into your project root.
2. Run `npm install`.
3. Start with `npm run dev`.
4. Use the included prompt file to bootstrap Codex workflows.

