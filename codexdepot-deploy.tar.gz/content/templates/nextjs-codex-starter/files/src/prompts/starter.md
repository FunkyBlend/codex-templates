# Starter Prompt

Use this prompt to begin project-scoped Codex tasks:

1. Summarize the current repository architecture.
2. Propose an implementation plan with milestones.
3. Implement incrementally with validation after each milestone.

