# Pre-Commit Safety Hook

## Usage
Run this hook before each commit to verify quick static checks and formatting rules.

