# Codex Quality Profile

## Usage
Apply this profile to standardize review strictness, validation defaults, and safety gates.

