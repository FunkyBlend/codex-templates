---
id: agent.your-agent-slug
type: agent
title: Your Agent Title
summary: One sentence explaining what this agent is for.
tags: [review, automation, codex]
author: "@your-handle"
license: MIT
compatibility: [codex-cli]
updated_at: 2026-02-20
difficulty: intermediate
---

# Your Agent Title

## Usage
Describe the expected prompt contract, inputs, and outputs.

