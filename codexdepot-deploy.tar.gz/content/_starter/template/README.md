# Your Template Title

## Usage
Explain when this template should be used and what it generates.

