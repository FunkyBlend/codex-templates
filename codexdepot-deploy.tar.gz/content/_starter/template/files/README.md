Place template files in this folder.

