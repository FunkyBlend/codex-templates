# Your Hook Title

## Usage
Describe trigger conditions, runtime assumptions, and safety boundaries.

