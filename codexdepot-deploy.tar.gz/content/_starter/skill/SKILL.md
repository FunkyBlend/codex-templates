---
id: skill.your-skill-slug
type: skill
title: Your Skill Title
summary: One sentence explaining what this skill does.
tags: [productivity, codex, workflow]
author: "@your-handle"
license: MIT
compatibility: [codex-cli]
updated_at: 2026-02-20
difficulty: beginner
---

# Your Skill Title

## Usage
1. Explain when to use this skill.
2. Add concrete steps.
3. Include an example command or prompt.

