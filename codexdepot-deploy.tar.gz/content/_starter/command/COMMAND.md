---
id: command.your-command-slug
type: command
title: Your Command Title
summary: One sentence describing this command workflow.
tags: [cli, workflow, codex]
author: "@your-handle"
license: MIT
compatibility: [codex-cli, github]
updated_at: 2026-02-20
difficulty: beginner
---

# Your Command Title

## Usage
Document command behavior, arguments, and expected output.

